import viewClassroom from "./viewClassroom.module.css";
import courseImg from "./assets/courseImg.png";
const ClassroomComponent = () => {
  return (
    <div className={viewClassroom.container}>
      <div className={viewClassroom.image}>
        <img src={courseImg} alt="course-image" />
      </div>
      <div className={viewClassroom.content}>
        <h3>Title : Introduction to C++</h3>
        <p>
          Description : This course covers the basics of C++, including syntax,
          data types, and control structures. Learn to write efficient code and
          develop simple applications using object-oriented programming
          principles. Gain hands-on experience through exercises and projects,
          building a strong foundation in C++
        </p>
      </div>
      <div className={viewClassroom.info}>
        <p>Start Time : 07:35 PM</p>
        <p>
          <strong>Private</strong>
        </p>
      </div>
    </div>
  );
};

export default ClassroomComponent;
