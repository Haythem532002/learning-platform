import sidebar from "./sidebar.module.css";
import logo from "./assets/logo.jpg";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { faMessage, faPlus } from "@fortawesome/free-solid-svg-icons";
import { faChartSimple } from "@fortawesome/free-solid-svg-icons/faChartSimple";
import { faUser } from "@fortawesome/free-solid-svg-icons/faUser";
import { faBell } from "@fortawesome/free-solid-svg-icons/faBell";
import { faEye } from "@fortawesome/free-solid-svg-icons/faEye";
import { faArrowRightFromBracket } from "@fortawesome/free-solid-svg-icons/faArrowRightFromBracket";
const Sidebar = () => {
  return (
    <div className={sidebar.sidebarContainer}>
      <div className={sidebar.sidebarHeader}>
        <img src={logo} alt="image" />
        <h3>Nom Prenom </h3>
      </div>
      <div className={sidebar.sidebarLinks}>
        <ul>
          <li>
            <a href="">
              <FontAwesomeIcon className={sidebar.icons} icon={faPlus} />
              Create Classroom
            </a>
          </li>
          <li>
            <a href="">
              <FontAwesomeIcon className={sidebar.icons} icon={faEye} />
              View Classrooms
            </a>
          </li>
          <li>
            <a href="">
              <FontAwesomeIcon className={sidebar.icons} icon={faMessage} />
              Messages
            </a>
          </li>
          <li>
            <a href="">
              <FontAwesomeIcon className={sidebar.icons} icon={faChartSimple} />
              Reports and analytics
            </a>
          </li>
          <li>
            <a href="">
              <FontAwesomeIcon className={sidebar.icons} icon={faUser} />
              Profile
            </a>
          </li>
          <li>
            <a href="">
              <FontAwesomeIcon className={sidebar.icons} icon={faBell} />
              Notification
            </a>
          </li>
        </ul>
      </div>
      <div className={sidebar.sidebarLogout}>
        <button>
          <FontAwesomeIcon
            className={sidebar.icons}
            icon={faArrowRightFromBracket}
          />
          Logout
        </button>
      </div>
    </div>
  );
};

export default Sidebar;
