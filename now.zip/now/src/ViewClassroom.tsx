import ClassroomComponent from "./ClassroomComponent";

const ViewClassroom = () => {
  return (
    <div>
        <ClassroomComponent />
        <ClassroomComponent />
        <ClassroomComponent />
        <ClassroomComponent />
        <ClassroomComponent />
    </div>
  );
};

export default ViewClassroom;
