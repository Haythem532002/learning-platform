export type Classroom = {
  title: string;
  description: string;
  isPublic: boolean;
  image: unknown;
  startTime: Date;
};
