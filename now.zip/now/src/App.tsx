import "./App.css";
import CreateClassroom from "./CreateClassroom";
import Sidebar from "./Sidebar";

function App() {
  return (
    <div
      style={{
        maxHeight: "100vh",
        maxWidth: "100vw",
        display: "flex",
      }}
    >
      <Sidebar />
      <div className="content">
        <CreateClassroom />
        
      </div>
    </div>
  );
}

export default App;
